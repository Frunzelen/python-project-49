### Hexlet tests and linter status:
[![Actions Status](https://github.com/Frunzelen/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/Frunzelen/python-project-49/actions)

# 📁 Проект в хекслет "Игры разума"

## Выполнение заданий реализовано в папке brain_games/scripts
